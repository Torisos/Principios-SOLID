/**
 * Envia notificaciones por SMS.
 *
 * Un canal de SMS
 * no manda correos, ni push, ni adjunta archivos.
 */
public class NotificadorSMS implements ServicioNotificacion
{
    public void enviarCorreo(String destino, String mensaje)
    {
        // No se ha implementado.
    }

    public void enviarSMS(String telefono, String mensaje)
    {
        System.out.println("[SMS] Para: " + telefono + " -> " + mensaje);
    }

    public void enviarPush(String idDispositivo, String mensaje)
    {
        // No se ha implementado.
    }

    public void adjuntarFacturaPDF(String rutaArchivo)
    {
        // No se ha implementado.
    }
}
