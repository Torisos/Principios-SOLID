/**
 * Producto descargable (ebook, licencia, curso).
 *
 */
public class ProductoDigital extends Producto
{
    private double tamañoMB;

    public ProductoDigital(String id, String nombre, double precio, double tamañoMB)
    {
        super(id, nombre, precio, 0, "digital");
        this.tamañoMB = tamañoMB;
    }

    public double getTamañoMB() { return tamañoMB; }

    @Override
    public double getPesoEnvio()
    {
        throw new UnsupportedOperationException("Un producto digital no se envia");
    }
}
