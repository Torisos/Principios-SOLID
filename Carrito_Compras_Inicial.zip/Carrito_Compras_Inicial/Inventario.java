/**
 * Controla el stock disponible.
 */
public class Inventario
{
    private MySQLBaseDatos db;

    public Inventario()
    {
        this.db = new MySQLBaseDatos();
        this.db.conectar();
    }

    public boolean hayStock(Producto producto, int cantidad)
    {
        String disponible = db.consultar("inventario", producto.getId());
        return Integer.parseInt(disponible) >= cantidad;
    }

    public void descontarStock(Producto producto, int cantidad)
    {
        db.actualizar("inventario", producto.getId(), "stock = stock - " + cantidad);
    }
}
