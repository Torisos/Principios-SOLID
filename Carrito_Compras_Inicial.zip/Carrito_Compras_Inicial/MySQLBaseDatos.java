/**
 * Simula la conexion a una base de datos MySQL para guardar los registros
 * de facturas y compras que se ha realizado
 */
public class MySQLBaseDatos
{
    private boolean conectada;

    public void conectar()
    {
        conectada = true;
        System.out.println("[MySQL] Conexion abierta");
    }

    public void insertar(String tabla, String datos)
    {
        System.out.println("[MySQL] INSERT INTO " + tabla + " VALUES (" + datos + ")");
    }

    public String consultar(String tabla, String llave)
    {
        System.out.println("[MySQL] SELECT * FROM " + tabla + " WHERE id=" + llave);
        return "100";
    }

    public void actualizar(String tabla, String llave, String datos)
    {
        System.out.println("[MySQL] UPDATE " + tabla + " SET " + datos + " WHERE id=" + llave);
    }

    public void desconectar()
    {
        conectada = false;
        System.out.println("[MySQL] Conexion cerrada");
    }
}
