/**
 * Representa un producto del catalogo de la tienda.
 */
public class Producto
{
    private String id;
    private String nombre;
    private double precio;
    private double peso;
    private String categoria;

    public Producto(String id, String nombre, double precio, double peso, String categoria)
    {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.peso = peso;
        this.categoria = categoria;
    }

    public String getId() { return id; }

    public String getNombre() { return nombre; }

    public double getPrecio() { return precio; }

    public String getCategoria() { return categoria; }

    /**
     * Devuelve el peso que se usa para calcular el costo de envio.
     */
    public double getPesoEnvio()
    {
        return peso;
    }
}
