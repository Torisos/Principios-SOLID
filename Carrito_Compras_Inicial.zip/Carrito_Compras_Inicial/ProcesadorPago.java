/**
 * Procesa el pago del pedido.
 * 
 * El metodo procesar() decide con if/else segun un String. 
 * Agregar Nequi, Daviplata o cripto obliga a modificar esta clase.
 */
public class ProcesadorPago
{
    public boolean procesar(String metodo, double monto, Cliente cliente)
    {
        if (metodo.equals("TARJETA")) {
            System.out.println("Validando tarjeta de credito...");
            System.out.println("Cobrando $" + monto + " a " + cliente.getNombre());
            return true;
        }
        if (metodo.equals("PSE")) {
            System.out.println("Redirigiendo al banco via PSE...");
            System.out.println("Debitando $" + monto);
            return true;
        }
        if (metodo.equals("EFECTIVO")) {
            System.out.println("Generando recibo de pago en efectivo por $" + monto);
            return true;
        }
        System.out.println("Metodo de pago no soportado: " + metodo);
        return false;
    }
}
