import java.util.ArrayList;

/**
 * Pedido generado a partir de un carrito.
 *
 * VIOLACION DE SRP + DIP
 * ----------------------
 * Ademas de guardar los datos del pedido, orquesta el pago, descuenta
 * inventario y notifica al cliente
 * No hay forma de probar la clase sin cobrar plata de verdad.
 */
public class Pedido
{
    private String numero;
    private Cliente cliente;
    private ArrayList<ItemCarrito> items;
    private double total;
    private String estado;

    public Pedido(String numero, Carrito carrito)
    {
        this.numero = numero;
        this.cliente = carrito.getCliente();
        this.items = carrito.getItems();
        this.total = carrito.calcularTotal();
        this.estado = "PENDIENTE";
    }

    public String getNumero() { return numero; }

    public double getTotal() { return total; }

    public String getEstado() { return estado; }

    public void confirmar(String metodoPago)
    {
        ProcesadorPago procesador = new ProcesadorPago();
        Inventario inventario = new Inventario();
        NotificadorEmail notificador = new NotificadorEmail();

        for (ItemCarrito item : items) {
            if (!inventario.hayStock(item.getProducto(), item.getCantidad())) {
                System.out.println("Sin stock de " + item.getProducto().getNombre());
                this.estado = "RECHAZADO";
                return;
            }
        }

        boolean pagado = procesador.procesar(metodoPago, total, cliente);
        if (!pagado) {
            this.estado = "RECHAZADO";
            return;
        }

        for (ItemCarrito item : items) {
            inventario.descontarStock(item.getProducto(), item.getCantidad());
        }

        this.estado = "CONFIRMADO";
        notificador.enviarCorreo(cliente.getCorreo(),
            "Tu pedido " + numero + " fue confirmado. Total: $" + total);
    }
}
