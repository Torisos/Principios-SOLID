/**
 * Cliente de la tienda.
 * El tipo de cliente se guarda como String
 */
public class Cliente
{
    private String id;
    private String nombre;
    private String correo;
    private String telefono;
    private String tipo;

    public Cliente(String id, String nombre, String correo, String telefono, String tipo)
    {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.tipo = tipo;
    }

    public String getId() { return id; }

    public String getNombre() { return nombre; }

    public String getCorreo() { return correo; }

    public String getTelefono() { return telefono; }

    public String getTipo() { return tipo; }
}
