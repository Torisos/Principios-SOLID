import java.util.ArrayList;

/**
 * Carrito de compras.
 */
public class Carrito
{
    private ArrayList<ItemCarrito> items;
    private Cliente cliente;
    private String tipoEnvio;
    private String cupon;

    public Carrito(Cliente cliente)
    {
        this.items = new ArrayList<ItemCarrito>();
        this.cliente = cliente;
        this.tipoEnvio = "terrestre";
        this.cupon = "";
    }

    public void agregarItem(Producto producto, int cantidad)
    {
        for (ItemCarrito item : items) {
            if (item.getProducto().getId().equals(producto.getId())) {
                item.setCantidad(item.getCantidad() + cantidad);
                return;
            }
        }
        items.add(new ItemCarrito(producto, cantidad));
    }

    public void eliminarItem(String idProducto)
    {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getProducto().getId().equals(idProducto)) {
                items.remove(i);
                return;
            }
        }
    }

    public void setTipoEnvio(String tipoEnvio) { this.tipoEnvio = tipoEnvio; }

    public void setCupon(String cupon) { this.cupon = cupon; }

    public ArrayList<ItemCarrito> getItems() { return items; }

    public Cliente getCliente() { return cliente; }

    public double calcularSubtotal()
    {
        double total = 0;
        for (ItemCarrito item : items) {
            total = total + item.getSubtotal();
        }
        return total;
    }

    // Cada nuevo cupon obliga a modificar el metodo.
    public double calcularDescuento()
    {
        double subtotal = calcularSubtotal();
        if (cupon.equals("NAVIDAD")) {
            return subtotal * 0.10;
        }
        if (cupon.equals("BLACKFRIDAY")) {
            return subtotal * 0.25;
        }
        if (cliente.getTipo().equals("VIP")) {
            return subtotal * 0.05;
        }
        return 0;
    }

    // Revienta si el carrito contiene un ProductoDigital.
    public double calcularPesoTotal()
    {
        double peso = 0;
        for (ItemCarrito item : items) {
            peso = peso + item.getProducto().getPesoEnvio() * item.getCantidad();
        }
        return peso;
    }

    public double calcularCostoEnvio()
    {
        if (tipoEnvio.equals("terrestre")) {
            if (calcularSubtotal() > 100000) {
                return 0;
            }
            return Math.max(10000, calcularPesoTotal() * 1500);
        }
        if (tipoEnvio.equals("aereo")) {
            return Math.max(20000, calcularPesoTotal() * 3000);
        }
        return 0;
    }

    public double calcularImpuestos()
    {
        return (calcularSubtotal() - calcularDescuento()) * 0.19;
    }

    public double calcularTotal()
    {
        return calcularSubtotal() - calcularDescuento() + calcularImpuestos() + calcularCostoEnvio();
    }

    public void imprimirFactura()
    {
        System.out.println("=====================================");
        System.out.println("  FACTURA - Cliente: " + cliente.getNombre());
        System.out.println("=====================================");
        for (ItemCarrito item : items) {
            System.out.println("  " + item.getProducto().getNombre()
                + " x" + item.getCantidad() + "  $" + item.getSubtotal());
        }
        System.out.println("  Subtotal:  $" + calcularSubtotal());
        System.out.println("  Descuento: $" + calcularDescuento());
        System.out.println("  IVA:       $" + calcularImpuestos());
        System.out.println("  Envio:     $" + calcularCostoEnvio());
        System.out.println("  TOTAL:     $" + calcularTotal());
        System.out.println("=====================================");
    }

    public void guardarEnBaseDeDatos()
    {
        MySQLBaseDatos db = new MySQLBaseDatos();
        db.conectar();
        db.insertar("carritos", cliente.getId() + "|" + calcularTotal());
        db.desconectar();
    }
}
