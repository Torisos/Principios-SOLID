/**
 * Para probar el sistema y mostrar en la terminal.
 */
public class Tienda
{
    public static void main(String[] args)
    {
        Tienda tienda = new Tienda();
        tienda.demostrar();
        tienda.probarProducto();
    }

    public void demostrar()
    {
        Cliente cliente = new Cliente("C001", "Nicolas Duarte",
            "nduarte514@prueba.edu.co", "3001234567", "VIP");

        Producto teclado = new Producto("P001", "Teclado mecanico", 250000, 1.2, "tecnologia");
        Producto mouse = new Producto("P002", "Mouse inalambrico", 90000, 0.3, "tecnologia");

        Carrito carrito = new Carrito(cliente);
        carrito.agregarItem(teclado, 1);
        carrito.agregarItem(mouse, 2);
        carrito.setTipoEnvio("terrestre");
        carrito.setCupon("NAVIDAD");

        carrito.imprimirFactura();
        carrito.guardarEnBaseDeDatos();

        Pedido pedido = new Pedido("PED-001", carrito);
        pedido.confirmar("TARJETA");
        System.out.println("Estado del pedido: " + pedido.getEstado());
    }

    public void probarProducto()
    {
        System.out.println();
        System.out.println(" Carrito Con Producto Digital: ");
        Cliente cliente = new Cliente("C002", "Ana Maria", "ana@correo.com", "3009876543", "NORMAL");
        Carrito carrito = new Carrito(cliente);
        carrito.agregarItem(new ProductoDigital("P003", "Ebook de finanzas", 40000, 12.5), 1);

        try {
            carrito.calcularCostoEnvio();
        } catch (UnsupportedOperationException e) {
            System.out.println("No se pudo calcular el envio: " + e.getMessage());
        }
    }
}
