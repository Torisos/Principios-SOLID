/**
 * Interfaz de notificaciones.
 */
public interface ServicioNotificacion
{
    void enviarCorreo(String destino, String mensaje);

    void enviarSMS(String telefono, String mensaje);

    void enviarPush(String idDispositivo, String mensaje);

    void adjuntarFacturaPDF(String rutaArchivo);
}
