/**
 * Envia notificaciones por correo.
 *
 * implementa enviarSMS() y enviarPush() aunque
 * no los usa.
 */
public class NotificadorEmail implements ServicioNotificacion
{
    public void enviarCorreo(String destino, String mensaje)
    {
        System.out.println("[EMAIL] Para: " + destino + " -> " + mensaje);
    }

    public void enviarSMS(String telefono, String mensaje)
    {
    }

    public void enviarPush(String idDispositivo, String mensaje)
    {
    }

    public void adjuntarFacturaPDF(String rutaArchivo)
    {
        System.out.println("[EMAIL] Adjuntando factura: " + rutaArchivo);
    }
}
