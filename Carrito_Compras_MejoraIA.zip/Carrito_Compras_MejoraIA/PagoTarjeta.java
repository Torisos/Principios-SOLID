/**
 * OCP - Pago con tarjeta de credito.
 */
public class PagoTarjeta implements MetodoPago
{
    private String numeroEnmascarado;

    public PagoTarjeta(String numeroEnmascarado)
    {
        this.numeroEnmascarado = numeroEnmascarado;
    }

    public boolean pagar(double monto, Cliente cliente)
    {
        System.out.println("Validando tarjeta " + numeroEnmascarado + "...");
        System.out.println("Cobrando $" + monto + " a " + cliente.getNombre());
        return true;
    }

    public String getNombre() { return "Tarjeta de credito"; }
}
