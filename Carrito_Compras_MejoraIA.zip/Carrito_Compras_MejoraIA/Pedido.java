import java.util.ArrayList;

/**
 * Pedido generado a partir de un carrito.
 *
 * SRP - APLICADO
 * --------------
 * Ahora es solo el modelo del pedido: guarda sus datos y su estado.
 * La orquestacion (cobrar, descontar stock, notificar) se movio a
 * ProcesadorPedido.
 */
public class Pedido
{
    private String numero;
    private Cliente cliente;
    private ArrayList<ItemCarrito> items;
    private double total;
    private String estado;

    public Pedido(String numero, Carrito carrito, double total)
    {
        this.numero = numero;
        this.cliente = carrito.getCliente();
        this.items = carrito.getItems();
        this.total = total;
        this.estado = "PENDIENTE";
    }

    public String getNumero() { return numero; }

    public Cliente getCliente() { return cliente; }

    public ArrayList<ItemCarrito> getItems() { return items; }

    public double getTotal() { return total; }

    public String getEstado() { return estado; }

    public void setEstado(String estado) { this.estado = estado; }
}
