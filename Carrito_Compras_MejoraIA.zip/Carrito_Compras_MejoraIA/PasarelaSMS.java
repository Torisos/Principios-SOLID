/**
 * ISP - Implementa unicamente el canal de SMS.
 * En el diseno inicial esta clase tenia tres metodos vacios.
 */
public class PasarelaSMS implements NotificacionSMS
{
    public void enviarSMS(String telefono, String mensaje)
    {
        System.out.println("[SMS] Para: " + telefono + " -> " + mensaje);
    }
}
