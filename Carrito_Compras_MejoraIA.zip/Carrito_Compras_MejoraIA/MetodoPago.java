/**
 * Forma de pago del pedido.
 *
 * OCP (Abierto/Cerrado) - APLICADO
 * --------------------------------
 * Reemplaza el if/else por String de ProcesadorPago. Nequi, Daviplata o
 * cripto entran como clases nuevas sin tocar el codigo existente.
 */
public interface MetodoPago
{
    boolean pagar(double monto, Cliente cliente);

    String getNombre();
}
