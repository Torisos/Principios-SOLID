/**
 * Forma de despacho del pedido.
 *
 * OCP (Abierto/Cerrado) - APLICADO
 * --------------------------------
 * Es el equivalente exacto de la interfaz Shipping de las diapositivas.
 * Reemplaza el if (tipoEnvio == "terrestre") / "aereo" de Carrito.
 * Agregar un transportador nuevo no obliga a modificar ninguna clase.
 */
public interface MetodoEnvio
{
    double calcularCosto(Carrito carrito);

    int diasEstimados();

    String getNombre();
}
