/**
 * ISP - Canal de notificacion por mensaje de texto.
 */
public interface NotificacionSMS
{
    void enviarSMS(String telefono, String mensaje);
}
