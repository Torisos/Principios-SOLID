/**
 * OCP - Pago contra entrega en efectivo.
 */
public class PagoEfectivo implements MetodoPago
{
    public boolean pagar(double monto, Cliente cliente)
    {
        System.out.println("Generando recibo de pago en efectivo por $" + monto);
        return true;
    }

    public String getNombre() { return "Efectivo"; }
}
