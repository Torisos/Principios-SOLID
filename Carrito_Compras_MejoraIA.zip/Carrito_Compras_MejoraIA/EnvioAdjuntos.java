/**
 * ISP - Capacidad de adjuntar archivos, separada de los canales.
 * Solo la implementa quien realmente puede hacerlo.
 */
public interface EnvioAdjuntos
{
    void adjuntarArchivo(String rutaArchivo);
}
