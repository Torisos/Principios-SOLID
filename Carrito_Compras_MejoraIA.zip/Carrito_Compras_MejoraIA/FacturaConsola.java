/**
 * SRP - Implementacion de factura en texto plano por consola.
 */
public class FacturaConsola implements PresentadorFactura
{
    public void mostrar(Carrito carrito, CalculadoraTotales calculadora)
    {
        System.out.println("=====================================");
        System.out.println("  FACTURA - Cliente: " + carrito.getCliente().getNombre());
        System.out.println("=====================================");
        for (ItemCarrito item : carrito.getItems()) {
            System.out.println("  " + item.getProducto().getNombre()
                + " x" + item.getCantidad() + "  $" + item.getSubtotal());
        }
        System.out.println("  Subtotal:  $" + carrito.calcularSubtotal());
        System.out.println("  Descuento: $" + calculadora.calcularDescuento(carrito)
            + "  (" + calculadora.getDescuento().getDescripcion() + ")");
        System.out.println("  IVA:       $" + calculadora.calcularImpuestos(carrito));
        System.out.println("  Envio:     $" + calculadora.calcularCostoEnvio(carrito)
            + "  (" + calculadora.getEnvio().getNombre()
            + ", " + calculadora.getEnvio().diasEstimados() + " dias)");
        System.out.println("  TOTAL:     $" + calculadora.calcularTotal(carrito));
        System.out.println("=====================================");
    }
}
