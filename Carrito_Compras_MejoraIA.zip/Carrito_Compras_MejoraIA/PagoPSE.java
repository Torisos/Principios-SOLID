/**
 * OCP - Pago por debito bancario PSE.
 */
public class PagoPSE implements MetodoPago
{
    private String banco;

    public PagoPSE(String banco)
    {
        this.banco = banco;
    }

    public boolean pagar(double monto, Cliente cliente)
    {
        System.out.println("Redirigiendo a " + banco + " via PSE...");
        System.out.println("Debitando $" + monto);
        return true;
    }

    public String getNombre() { return "PSE - " + banco; }
}
