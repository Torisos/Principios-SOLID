/**
 * Muestra la factura de un carrito.
 *
 * SRP - APLICADO: la presentacion sale de Carrito y vive en su propia
 * jerarquia, igual que TimeSheetReport salio de Employee en la diapositiva.
 * OCP - APLICADO: se puede agregar una factura en HTML o PDF sin tocar
 * nada del dominio.
 */
public interface PresentadorFactura
{
    void mostrar(Carrito carrito, CalculadoraTotales calculadora);
}
