/**
 * OCP - Descuento del 5% para clientes VIP.
 *
 * Nota: la categoria del cliente dejo de ser un String suelto dentro de
 * Carrito. Ahora es una politica con su propia clase.
 */
public class DescuentoClienteVIP implements EstrategiaDescuento
{
    public double calcular(Carrito carrito)
    {
        return carrito.calcularSubtotal() * 0.05;
    }

    public String getDescripcion()
    {
        return "Descuento cliente VIP (5%)";
    }
}
