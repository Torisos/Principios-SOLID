/**
 * DIP - Segundo detalle de bajo nivel.
 *
 * Su existencia es la prueba del principio: cambiar el motor de base de
 * datos no obliga a modificar Inventario ni ninguna clase de negocio.
 * En el diseno inicial esto era imposible.
 */
public class MongoBaseDatos implements BaseDatos
{
    public void conectar()
    {
        System.out.println("[MongoDB] Cliente conectado");
    }

    public void insertar(String coleccion, String datos)
    {
        System.out.println("[MongoDB] db." + coleccion + ".insertOne({" + datos + "})");
    }

    public String consultar(String coleccion, String llave)
    {
        System.out.println("[MongoDB] db." + coleccion + ".findOne({_id:" + llave + "})");
        return "100";
    }

    public void actualizar(String coleccion, String llave, String datos)
    {
        System.out.println("[MongoDB] db." + coleccion + ".updateOne({_id:" + llave + "})");
    }

    public void desconectar()
    {
        System.out.println("[MongoDB] Cliente cerrado");
    }
}
