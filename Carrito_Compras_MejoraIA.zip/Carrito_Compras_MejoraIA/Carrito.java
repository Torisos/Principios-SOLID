import java.util.ArrayList;

/**
 * Carrito de compras.
 *
 * SRP (Responsabilidad Unica) - APLICADO
 * --------------------------------------
 * Esta clase ahora tiene UNA sola razon para cambiar: la forma de
 * administrar los items. Ya no calcula descuentos, ni envio, ni
 * impuestos, ni imprime facturas, ni habla con la base de datos.
 * Esas responsabilidades se movieron a CalculadoraTotales,
 * PresentadorFactura y las estrategias correspondientes.
 */
public class Carrito
{
    private ArrayList<ItemCarrito> items;
    private Cliente cliente;

    public Carrito(Cliente cliente)
    {
        this.items = new ArrayList<ItemCarrito>();
        this.cliente = cliente;
    }

    public void agregarItem(Producto producto, int cantidad)
    {
        for (ItemCarrito item : items) {
            if (item.getProducto().getId().equals(producto.getId())) {
                item.setCantidad(item.getCantidad() + cantidad);
                return;
            }
        }
        items.add(new ItemCarrito(producto, cantidad));
    }

    public void eliminarItem(String idProducto)
    {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getProducto().getId().equals(idProducto)) {
                items.remove(i);
                return;
            }
        }
    }

    public ArrayList<ItemCarrito> getItems() { return items; }

    public Cliente getCliente() { return cliente; }

    public double calcularSubtotal()
    {
        double total = 0;
        for (ItemCarrito item : items) {
            total = total + item.getSubtotal();
        }
        return total;
    }

    /**
     * Suma el peso unicamente de los productos fisicos.
     * Unico punto del sistema donde se distingue el tipo de producto,
     * y no lanza excepciones: los digitales simplemente no suman peso.
     */
    public double calcularPesoTotal()
    {
        double peso = 0;
        for (ItemCarrito item : items) {
            if (item.getProducto() instanceof ProductoFisico) {
                ProductoFisico fisico = (ProductoFisico) item.getProducto();
                peso = peso + fisico.getPesoEnvio() * item.getCantidad();
            }
        }
        return peso;
    }

    public boolean contieneProductosFisicos()
    {
        for (ItemCarrito item : items) {
            if (item.getProducto() instanceof ProductoFisico) {
                return true;
            }
        }
        return false;
    }
}
