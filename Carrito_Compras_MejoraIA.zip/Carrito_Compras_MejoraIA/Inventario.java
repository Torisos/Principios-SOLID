/**
 * Controla el stock disponible.
 *
 * DIP - APLICADO
 * --------------
 * Es una clase de ALTO NIVEL y ahora depende de la abstraccion BaseDatos,
 * que recibe por constructor. Ya no hace "new MySQLBaseDatos()", asi que
 * no conoce ningun motor concreto y se puede probar con una base falsa.
 * Es el arreglo de BudgetReport -> Database de la diapositiva.
 */
public class Inventario
{
    private BaseDatos db;

    public Inventario(BaseDatos db)
    {
        this.db = db;
        this.db.conectar();
    }

    public boolean hayStock(Producto producto, int cantidad)
    {
        String disponible = db.consultar("inventario", producto.getId());
        return Integer.parseInt(disponible) >= cantidad;
    }

    public void descontarStock(Producto producto, int cantidad)
    {
        db.actualizar("inventario", producto.getId(), "stock = stock - " + cantidad);
    }
}
