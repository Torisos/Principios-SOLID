/**
 * OCP - Envio por tierra. Gratis en compras superiores a $100.000,
 * de lo contrario $1.500 por kilo con un minimo de $10.000.
 */
public class EnvioTerrestre implements MetodoEnvio
{
    public double calcularCosto(Carrito carrito)
    {
        if (carrito.calcularSubtotal() > 100000) {
            return 0;
        }
        return Math.max(10000, carrito.calcularPesoTotal() * 1500);
    }

    public int diasEstimados() { return 5; }

    public String getNombre() { return "Terrestre"; }
}
