/**
 * OCP - Caso por defecto. Evita tener que preguntar por null.
 */
public class SinDescuento implements EstrategiaDescuento
{
    public double calcular(Carrito carrito)
    {
        return 0;
    }

    public String getDescripcion()
    {
        return "Sin descuento";
    }
}
