/**
 * OCP - Envio aereo. $3.000 por kilo con un minimo de $20.000.
 */
public class EnvioAereo implements MetodoEnvio
{
    public double calcularCosto(Carrito carrito)
    {
        return Math.max(20000, carrito.calcularPesoTotal() * 3000);
    }

    public int diasEstimados() { return 2; }

    public String getNombre() { return "Aereo"; }
}
