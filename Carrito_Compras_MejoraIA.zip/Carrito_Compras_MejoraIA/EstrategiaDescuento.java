/**
 * Politica de descuento aplicable a un carrito.
 *
 * OCP (Abierto/Cerrado) - APLICADO
 * --------------------------------
 * Reemplaza la cadena de if de Carrito.calcularDescuento(). Un cupon
 * nuevo se agrega creando una clase que implemente esta interfaz;
 * ninguna clase existente se modifica.
 */
public interface EstrategiaDescuento
{
    double calcular(Carrito carrito);

    String getDescripcion();
}
