/**
 * Canal de notificacion por correo.
 *
 * ISP (Segregacion de Interfaces) - APLICADO
 * ------------------------------------------
 * La interfaz gruesa ServicioNotificacion se partio en interfaces
 * pequenas y especificas, igual que CloudProvider se dividio en
 * CloudHostingProvider, CDNProvider y CloudStorageProvider.
 * Ningun implementador queda obligado a dejar metodos vacios.
 */
public interface NotificacionCorreo
{
    void enviarCorreo(String destino, String asunto, String mensaje);
}
