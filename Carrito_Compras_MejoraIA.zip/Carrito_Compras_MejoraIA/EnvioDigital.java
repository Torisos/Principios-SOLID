/**
 * OCP + LSP - Entrega por descarga, sin costo ni peso.
 *
 * Este caso era imposible de representar en el diseno inicial: alli el
 * producto digital rompia el calculo de envio. Aqui es simplemente otra
 * implementacion mas de MetodoEnvio.
 */
public class EnvioDigital implements MetodoEnvio
{
    public double calcularCosto(Carrito carrito)
    {
        return 0;
    }

    public int diasEstimados() { return 0; }

    public String getNombre() { return "Descarga inmediata"; }
}
