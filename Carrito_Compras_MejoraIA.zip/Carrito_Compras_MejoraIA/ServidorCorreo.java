/**
 * ISP - Implementa unicamente lo que sabe hacer: correo y adjuntos.
 * Cero metodos vacios.
 */
public class ServidorCorreo implements NotificacionCorreo, EnvioAdjuntos
{
    public void enviarCorreo(String destino, String asunto, String mensaje)
    {
        System.out.println("[EMAIL] Para: " + destino + " | " + asunto + " -> " + mensaje);
    }

    public void adjuntarArchivo(String rutaArchivo)
    {
        System.out.println("[EMAIL] Adjuntando: " + rutaArchivo);
    }
}
