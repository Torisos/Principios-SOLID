/**
 * DIP - Detalle de bajo nivel. Depende de la abstraccion BaseDatos.
 */
public class MySQLBaseDatos implements BaseDatos
{
    public void conectar()
    {
        System.out.println("[MySQL] Conexion abierta");
    }

    public void insertar(String tabla, String datos)
    {
        System.out.println("[MySQL] INSERT INTO " + tabla + " VALUES (" + datos + ")");
    }

    public String consultar(String tabla, String llave)
    {
        System.out.println("[MySQL] SELECT * FROM " + tabla + " WHERE id=" + llave);
        return "100";
    }

    public void actualizar(String tabla, String llave, String datos)
    {
        System.out.println("[MySQL] UPDATE " + tabla + " SET " + datos + " WHERE id=" + llave);
    }

    public void desconectar()
    {
        System.out.println("[MySQL] Conexion cerrada");
    }
}
