/**
 * Calcula los totales de un carrito.
 *
 * SRP - APLICADO: su unica razon para cambiar es la formula de totales.
 * OCP + DIP - APLICADO: no conoce cupones ni transportadores concretos.
 * Recibe las abstracciones EstrategiaDescuento y MetodoEnvio por
 * constructor, asi que jamas necesita un if para decidir cual usar.
 */
public class CalculadoraTotales
{
    private EstrategiaDescuento descuento;
    private MetodoEnvio envio;
    private double tasaImpuesto;

    public CalculadoraTotales(EstrategiaDescuento descuento, MetodoEnvio envio, double tasaImpuesto)
    {
        this.descuento = descuento;
        this.envio = envio;
        this.tasaImpuesto = tasaImpuesto;
    }

    public EstrategiaDescuento getDescuento() { return descuento; }

    public MetodoEnvio getEnvio() { return envio; }

    public double calcularDescuento(Carrito carrito)
    {
        return descuento.calcular(carrito);
    }

    public double calcularCostoEnvio(Carrito carrito)
    {
        return envio.calcularCosto(carrito);
    }

    public double calcularImpuestos(Carrito carrito)
    {
        return (carrito.calcularSubtotal() - calcularDescuento(carrito)) * tasaImpuesto;
    }

    public double calcularTotal(Carrito carrito)
    {
        return carrito.calcularSubtotal()
             - calcularDescuento(carrito)
             + calcularImpuestos(carrito)
             + calcularCostoEnvio(carrito);
    }
}
