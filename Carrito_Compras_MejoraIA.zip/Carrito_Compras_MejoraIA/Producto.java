/**
 * Clase base de todo producto vendible.
 *
 * LSP (Sustitucion de Liskov) - APLICADO
 * --------------------------------------
 * Esta clase ya NO declara getPesoEnvio(). Solo expone el contrato que
 * TODOS los productos pueden cumplir de verdad. Es el mismo arreglo de la
 * diapositiva: Animal se quedo solo con walk(), y jump() bajo a
 * LightweightAnimal. Aqui el peso baja a ProductoFisico.
 */
public abstract class Producto
{
    private String id;
    private String nombre;
    private double precio;
    private String categoria;

    public Producto(String id, String nombre, double precio, String categoria)
    {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.categoria = categoria;
    }

    public String getId() { return id; }

    public String getNombre() { return nombre; }

    public double getPrecio() { return precio; }

    public String getCategoria() { return categoria; }
}
