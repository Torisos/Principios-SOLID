/**
 * Clase de arranque. Demuestra los cinco principios ya aplicados.
 *
 * Es el unico punto del sistema que decide QUE implementaciones concretas
 * se usan; todo lo demas trabaja contra abstracciones.
 */
public class Tienda
{
    public static void main(String[] args)
    {
        Tienda tienda = new Tienda();
        tienda.escenarioProductosFisicos();
        tienda.escenarioProductoDigital();
        tienda.escenarioCambioDeMotorBD();
    }

    /**
     * Compra normal: cupon de navidad, envio terrestre, pago con tarjeta.
     */
    public void escenarioProductosFisicos()
    {
        System.out.println(">>> ESCENARIO 1: productos fisicos");

        Cliente cliente = new Cliente("C001", "Camilo Sanabria", "camilo@correo.com", "3001234567");
        Carrito carrito = new Carrito(cliente);
        carrito.agregarItem(new ProductoFisico("P001", "Teclado mecanico", 250000, 1.2, "tecnologia"), 1);
        carrito.agregarItem(new ProductoFisico("P002", "Mouse inalambrico", 90000, 0.3, "tecnologia"), 2);

        CalculadoraTotales calculadora = new CalculadoraTotales(
            new DescuentoNavidad(), new EnvioTerrestre(), 0.19);

        PresentadorFactura factura = new FacturaConsola();
        factura.mostrar(carrito, calculadora);

        ProcesadorPedido procesador = new ProcesadorPedido(
            new Inventario(new MySQLBaseDatos()),
            new PagoTarjeta("**** 4321"),
            new ServidorCorreo());

        Pedido pedido = procesador.procesar("PED-001", carrito, calculadora);
        System.out.println("Estado del pedido: " + pedido.getEstado());
        System.out.println();
    }

    /**
     * LSP resuelto: el mismo flujo con un producto digital ya no lanza
     * ninguna excepcion. Antes esto rompia el calculo de envio.
     */
    public void escenarioProductoDigital()
    {
        System.out.println(">>> ESCENARIO 2: producto digital (LSP corregido)");

        Cliente cliente = new Cliente("C002", "Ana Gomez", "ana@correo.com", "3009876543");
        Carrito carrito = new Carrito(cliente);
        carrito.agregarItem(new ProductoDigital("P003", "Ebook de finanzas", 40000, 12.5), 1);

        CalculadoraTotales calculadora = new CalculadoraTotales(
            new SinDescuento(), new EnvioDigital(), 0.19);

        new FacturaConsola().mostrar(carrito, calculadora);

        ProcesadorPedido procesador = new ProcesadorPedido(
            new Inventario(new MySQLBaseDatos()),
            new PagoPSE("Bancolombia"),
            new ServidorCorreo());

        Pedido pedido = procesador.procesar("PED-002", carrito, calculadora);
        System.out.println("Estado del pedido: " + pedido.getEstado());
        System.out.println();
    }

    /**
     * DIP demostrado: se cambia MySQL por MongoDB y ninguna clase de
     * negocio se entera. Solo cambia esta linea de configuracion.
     */
    public void escenarioCambioDeMotorBD()
    {
        System.out.println(">>> ESCENARIO 3: cambio de motor de base de datos (DIP)");

        Cliente cliente = new Cliente("C003", "Luis Perez", "luis@correo.com", "3005558888");
        Carrito carrito = new Carrito(cliente);
        carrito.agregarItem(new ProductoFisico("P004", "Silla ergonomica", 480000, 12.0, "hogar"), 1);

        CalculadoraTotales calculadora = new CalculadoraTotales(
            new DescuentoClienteVIP(), new EnvioAereo(), 0.19);

        ProcesadorPedido procesador = new ProcesadorPedido(
            new Inventario(new MongoBaseDatos()),
            new PagoEfectivo(),
            new ServidorCorreo());

        Pedido pedido = procesador.procesar("PED-003", carrito, calculadora);
        System.out.println("Total: $" + pedido.getTotal());
        System.out.println("Estado del pedido: " + pedido.getEstado());

        PasarelaSMS sms = new PasarelaSMS();
        sms.enviarSMS(cliente.getTelefono(), "Tu pedido PED-003 fue confirmado");
    }
}
