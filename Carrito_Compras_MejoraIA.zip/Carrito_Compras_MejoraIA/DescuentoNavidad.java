/**
 * OCP - Descuento del 10% por temporada navidena.
 */
public class DescuentoNavidad implements EstrategiaDescuento
{
    public double calcular(Carrito carrito)
    {
        return carrito.calcularSubtotal() * 0.10;
    }

    public String getDescripcion()
    {
        return "Cupon NAVIDAD (10%)";
    }
}
