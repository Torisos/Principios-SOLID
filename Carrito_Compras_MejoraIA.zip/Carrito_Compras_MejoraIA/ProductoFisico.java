/**
 * Producto tangible que se despacha fisicamente.
 *
 * LSP - APLICADO
 * Equivale a LightweightAnimal de la diapositiva: es el nivel de la
 * jerarquia donde SI tiene sentido hablar de peso de envio. Ninguna
 * subclase necesita lanzar excepciones para cumplir el contrato.
 */
public class ProductoFisico extends Producto
{
    private double peso;

    public ProductoFisico(String id, String nombre, double precio, double peso, String categoria)
    {
        super(id, nombre, precio, categoria);
        this.peso = peso;
    }

    public double getPesoEnvio()
    {
        return peso;
    }
}
