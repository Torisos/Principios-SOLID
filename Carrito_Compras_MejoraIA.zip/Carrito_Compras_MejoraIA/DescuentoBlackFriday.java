/**
 * OCP - Descuento del 25% por Black Friday.
 */
public class DescuentoBlackFriday implements EstrategiaDescuento
{
    public double calcular(Carrito carrito)
    {
        return carrito.calcularSubtotal() * 0.25;
    }

    public String getDescripcion()
    {
        return "Cupon BLACKFRIDAY (25%)";
    }
}
