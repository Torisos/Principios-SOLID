/**
 * Abstraccion de persistencia.
 *
 * DIP (Inversion de Dependencias) - APLICADO
 * ------------------------------------------
 * Es el equivalente de la interfaz Database de la diapositiva. Pertenece
 * conceptualmente al ALTO NIVEL: la define quien la consume (Inventario),
 * no quien la implementa. Los detalles concretos (MySQL, MongoDB) ahora
 * dependen de esta abstraccion, y no al reves.
 */
public interface BaseDatos
{
    void conectar();

    void insertar(String tabla, String datos);

    String consultar(String tabla, String llave);

    void actualizar(String tabla, String llave, String datos);

    void desconectar();
}
