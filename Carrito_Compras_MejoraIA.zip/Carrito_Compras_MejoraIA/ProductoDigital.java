/**
 * Producto descargable (ebook, licencia, curso).
 *
 * LSP - APLICADO
 * Ya no hereda un metodo que no puede cumplir, asi que no lanza ninguna
 * excepcion. Es sustituible por Producto en cualquier contexto.
 */
public class ProductoDigital extends Producto
{
    private double tamanoMB;

    public ProductoDigital(String id, String nombre, double precio, double tamanoMB)
    {
        super(id, nombre, precio, "digital");
        this.tamanoMB = tamanoMB;
    }

    public double getTamanoMB() { return tamanoMB; }

    public String getEnlaceDescarga()
    {
        return "https://tienda.com/descargas/" + getId();
    }
}
