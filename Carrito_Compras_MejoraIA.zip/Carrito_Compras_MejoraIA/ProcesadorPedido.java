/**
 * Orquesta la confirmacion de un pedido.
 *
 * SRP - APLICADO: su unica responsabilidad es coordinar el flujo.
 * DIP - APLICADO: recibe TODAS sus dependencias por constructor y solo
 * conoce abstracciones (Inventario, MetodoPago, NotificacionCorreo).
 * No instancia nada concreto, asi que se puede probar sin cobrar dinero
 * real ni tocar una base de datos.
 */
public class ProcesadorPedido
{
    private Inventario inventario;
    private MetodoPago metodoPago;
    private NotificacionCorreo notificador;

    public ProcesadorPedido(Inventario inventario, MetodoPago metodoPago, NotificacionCorreo notificador)
    {
        this.inventario = inventario;
        this.metodoPago = metodoPago;
        this.notificador = notificador;
    }

    public Pedido procesar(String numero, Carrito carrito, CalculadoraTotales calculadora)
    {
        double total = calculadora.calcularTotal(carrito);
        Pedido pedido = new Pedido(numero, carrito, total);

        for (ItemCarrito item : carrito.getItems()) {
            if (!inventario.hayStock(item.getProducto(), item.getCantidad())) {
                System.out.println("Sin stock de " + item.getProducto().getNombre());
                pedido.setEstado("RECHAZADO");
                return pedido;
            }
        }

        if (!metodoPago.pagar(total, carrito.getCliente())) {
            pedido.setEstado("RECHAZADO");
            return pedido;
        }

        for (ItemCarrito item : carrito.getItems()) {
            inventario.descontarStock(item.getProducto(), item.getCantidad());
        }

        pedido.setEstado("CONFIRMADO");
        notificador.enviarCorreo(carrito.getCliente().getCorreo(),
            "Pedido " + numero + " confirmado",
            "Pagaste $" + total + " con " + metodoPago.getNombre());
        return pedido;
    }
}
